var mongoose = require("mongoose");
var contactSchema = new mongoose.Schema({
    firstName: {type: String, required: true},
    lastName: {type: String, required: true},
    email:{type: String, required: true},
    userName:{type: String, required: true},
    password:{type: String, required: true},
    confirmPassword:{type: String, required: true},
    phoneNumber: {type: String, required: true},
    addtess: {type: String, required: true},
    inactive: {type:Boolean},
    isFavourite:{type:Boolean}
   });

module.exports = mongoose.model('contact', contactSchema);