
var Contact = require('../models/contact.model');


/**
 * This method is use for save contact data
 * param : contact json
 * return json
 */
exports.saveContactData=function(req, res) {
	console.log("Enter in a saveContactData Method:");
    var contact = new Contact(req.body);
    contact.save()
    .then(item => {
		return res.status(200).json("contact saved to database");
    })
    .catch(err => {
        res.status(400).send("unable to save to database");
    });
}

/**
 * This method is use for update contact data
 * param : contact json
 * return json
 */
exports.updateContact=function(req, res) {
	console.log("Enter in a updateContact Method:");
	Contact.update({"_id" : req.params.id},req.body).exec().then(contact=>{
		if(contact){
			return res.status(200).json("contact Updated to database");
		}else{
			return res.status(404).json("error");
		}
	}).catch(err=>{
		throw err;
	});
}

/**
 * This method is use for get particular contact data
 * param : contact id
 * return json
 */
exports.findById=function(req,res){
	console.log("Call findById doc list get ")
	Contact.findOne({"_id" : req.params.id}).exec(function(err,contacts){
		if(contacts){
			res.json(contacts);
		}else{
			res.status(404).json("contact are not availabel");
		}
    })
};

/**
 * This method is use for get All contact data
 * return json
 */
exports.getContactData=function(req,res){
	console.log("Call contact doc list get ")
	Contact.find({"inactive" : false}).exec(function(err,contacts){
		if(contacts){
			res.json(contacts);
		}else{
			res.status(404).json("contact are not availabel");
		}
    })
};

/**
 * This method is use for Delete contact data
 * param : contact id
 * return json
 */
exports.deleteContact=function(req,res){
	console.info("Enter in a deleteContact() Method:"+req.params.id);
	Contact.updateOne({"_id" : req.params.id},{$set: {"inactive":true}}).exec().then(contact=>{
		if(contact){
			return res.status(200).json("Deleted");
		}else{
			return res.status(404).json("error");
		}
	}).catch(err=>{
		throw err;
	});
}

/**
 * This method is use for add contact data to favourate 
 * param : contact id
 * return json
 */
exports.addToFavContact=function(req,res){
	console.info("Enter in a addToFavContact() Method:"+req.params.id);
	Contact.updateOne({"_id" : req.params.id},{$set: {"isFavourite":true}}).exec().then(contact=>{
		if(contact){
			return res.status(200).json("Add to Favourite");
		}else{
			return res.status(404).json("error");
		}
	}).catch(err=>{
		throw err;
	});
}

/**
 * This method is use for contact remove from favourate
 * param : contact id
 * return json
 */
exports.removeToFavourite=function(req,res){
	console.info("Enter in a removeToFavourite() Method:"+req.params.id);
	Contact.updateOne({"_id" : req.params.id},{$set: {"isFavourite":false}}).exec().then(contact=>{
		if(contact){
			return res.status(200).json("Add to Favourite");
		}else{
			return res.status(404).json("error");
		}
	}).catch(err=>{
		throw err;
	});
}