
var express = require('express');
var controller = require('../controllers/contact.controller');

// get an instance of the router for api routes
var apiRoutes = express.Router(); 

apiRoutes.get('/findById/:id',controller.findById);
apiRoutes.put('/updateContact/:id',controller.updateContact);
apiRoutes.get('/getAllContact', controller.getContactData);
apiRoutes.post('/saveContact',controller.saveContactData);
apiRoutes.delete('/deleteContact/:id',controller.deleteContact);
apiRoutes.put('/addToFavourite/:id',controller.addToFavContact);
apiRoutes.put('/removeToFavourite/:id',controller.removeToFavourite);

// Expose app
module.exports = apiRoutes;
