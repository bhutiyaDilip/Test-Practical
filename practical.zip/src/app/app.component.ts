import { Component, OnInit } from '@angular/core';
import { ContactComponent } from './contact/contact.component';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'practical';
  contactList :any = [];
  searchList :any = [];
  favContactList :any = [];
  fileNameDialogRef!: MatDialogRef<ContactComponent>;
  searchForm: any;

  constructor(private dialog: MatDialog, private http: HttpClient,private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.getContactList();
    this.searchForm = this.formBuilder.group({
      search: ['']
    });
  }
  
  openAddFileDialog(id) {

    console.log(id);
    this.fileNameDialogRef = this.dialog.open(ContactComponent,{
      minHeight:'400px',
      minWidth:'300px',
      disableClose: true,
      data: {"id" : id, "isEditMode": id!=null ? true : false}
    });

    this.fileNameDialogRef.afterClosed().subscribe(result=>{
      this.getContactList();
    })
  }

  //get All contact list
  getContactList() {
    const postUrl = "http://localhost:3000/api/getAllContact";
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    return this.http.get<string>(postUrl).subscribe((response)=>{
      console.log('repsonse ',response);
      this.contactList = response;
      this.favContactList = this.contactList.filter(obj => obj.isFavourite == true);
      this.searchList= this.contactList;
    });
  }

  //delete contect
  delete(id){
    console.log("Delete:::"+id);
    const postUrl = "http://localhost:3000/api/deleteContact/"+id;
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    return this.http.delete<string>(postUrl).subscribe((response)=>{
      this.getContactList();
    });
  }

  //delete addToFavourite
  addToFavourite(id){
    console.log("addToFavourite:::"+id);
    const postUrl = "http://localhost:3000/api/addToFavourite/"+id;
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    return this.http.put<string>(postUrl,null).subscribe((response)=>{
      this.getContactList();
    });
  }

  //remove from facourite
  removeFav(id){
    console.log("removeFav:::"+id);
    const postUrl = "http://localhost:3000/api/removeToFavourite/"+id;
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    return this.http.put<string>(postUrl,null).subscribe((response)=>{
      this.getContactList();
    });
  }

  //seach contact
  search(){
    console.log("search::" + this.searchForm.value.search);
    if(this.searchForm.value.search!=''){
      this.searchList = this.contactList.filter(obj => obj.userName.includes(this.searchForm.value.search));
    }else{
      this.searchList = this.contactList;
    }
  }
}
