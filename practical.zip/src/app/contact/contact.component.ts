import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  form: any;
  
  constructor(
    private formBuilder: FormBuilder,
    private dialogRef: MatDialogRef<ContactComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private http: HttpClient
) {}

ngOnInit() {
  
  if(this.data.isEditMode){
    this.getContactData();
    this.form = this.formBuilder.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required,Validators.email]],
      userName: ['', [Validators.required]],
      password: [''],
      confirmPassword: [''],
      phoneNumber: ['', [Validators.required]],
      addtess: ['', [Validators.required]]
    });
  }else{
    console.log(this.data);
    this.form = this.formBuilder.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
      userName: ['', [Validators.required]],
      password: ['', [Validators.required]],
      confirmPassword: ['', [Validators.required]],
      phoneNumber: ['', [Validators.required,Validators.pattern('[- +()0-9]+')]],
      addtess: ['', [Validators.required]],
      isFavourite: [false],
      inactive:[false]
    },{
      // check whether our password and confirm password match
      validators: this.checkIfMatchingPasswords('password', 'confirmPassword')
    });
  }
    
    
}
  onCloseDialog() {
      this.dialogRef.close();
  }

  //get single contect
  getContactData(){
    const postUrl = "http://localhost:3000/api/findById/"+this.data.id;
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    return this.http.get<string>(postUrl).subscribe((response:any)=>{
      console.log('repsonse ',response);

      this.form.patchValue({  
        firstName: response.firstName,
        lastName: response.lastName,
        email: response.email,
        userName: response.userName,
        phoneNumber: response.phoneNumber,
        addtess: response.addtess
      }); 
    });
  }

  //password match validation
  checkIfMatchingPasswords(passwordKey: string, passwordConfirmationKey: string) {
    return (group: FormGroup) => {
      const passwordInput = group.controls[passwordKey];
      const passwordConfirmationInput = group.controls[passwordConfirmationKey];
      if (passwordInput.value !== passwordConfirmationInput.value) {
        return passwordConfirmationInput.setErrors({ notEquivalent: true });
      }else if (passwordConfirmationInput.value === '') {
        return passwordConfirmationInput.setErrors({ required: true });
      } else {
        return passwordConfirmationInput.setErrors(null);
      }
    };
  }

  //save and update data
  submit() {
    if(this.data.isEditMode){
      const postUrl = "http://localhost:3000/api/updateContact/"+this.data.id;
      const headers = new HttpHeaders();
      headers.append('Content-Type', 'application/json');
      headers.append('Accept', 'application/json');
      var obj = this.form.value;
      delete obj.password;
      delete obj.confirmPassword;
      return this.http.put<string>(postUrl, obj ,{headers: headers}).subscribe((response)=>{
        console.log('repsonse ',response);
        this.dialogRef.close();
      });
    }else{
      const postUrl = "http://localhost:3000/api/saveContact";
      const headers = new HttpHeaders();
      headers.append('Content-Type', 'application/json');
      headers.append('Accept', 'application/json');
      return this.http.post<string>(postUrl, this.form.value,{headers: headers}).subscribe((response)=>{
        console.log('repsonse ',response);
        this.dialogRef.close();
      });
    }
  }
}
